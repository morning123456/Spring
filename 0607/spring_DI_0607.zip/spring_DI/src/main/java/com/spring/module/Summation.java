package com.spring.module;

public class Summation {
	
	public int sum(int a, int b) {
		return a+b;
		
	}
}


