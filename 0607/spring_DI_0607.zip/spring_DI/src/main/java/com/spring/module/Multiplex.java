package com.spring.module;

public class Multiplex {

	public int multi(int a, int b) {
	   return a*b;
	}
}
