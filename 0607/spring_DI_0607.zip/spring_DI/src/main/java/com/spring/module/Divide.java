package com.spring.module;

public class Divide {

	public float div(int a, int b) {
		return (float)a/b;
	}
}
