package com.spring.module;

public class Minus {

	public int minus(int a, int b) {
		return a-b;
	}
}
