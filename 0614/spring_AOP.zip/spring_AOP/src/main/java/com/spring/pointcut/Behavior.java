package com.spring.pointcut;

public interface Behavior {

	void 잠자기();
	void 공부하기();
	void 밥먹기();
	void 데이트();
	void 운동();
	void 놀기();
	void 정신수양();
	
	
}
